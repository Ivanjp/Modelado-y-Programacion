public interface Observador{
	public void update();
}
