public interface Sujeto{
	public void registrar(Cliente c);
	public void remover(Cliente c);
	public void notificar();
}
