
import java.util.List;

public interface Cobros{
	public void cobrar(List<Cliente> arr, Servicio s);
}
