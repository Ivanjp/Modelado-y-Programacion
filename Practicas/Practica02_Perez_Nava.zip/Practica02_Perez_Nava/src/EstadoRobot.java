public interface EstadoRobot{
	void camina();
	void recibeOrden();
	void reabastece();
	void trabaja();
	void construye();
	void activarse();
	void suspende();

}
